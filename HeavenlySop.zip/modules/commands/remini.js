const axios = require('axios');

module.exports.config = {
  name: "remini",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Fixed By Kim Joseph DG Bien",
  description: "Remini Photo Enhance",
  commandCategory: "utilities",
  cooldowns: 5
};

module.exports.run = async ({ api, event }) => {
  const attachments = event.attachments;
  if (!attachments || attachments.length === 0) {
    return api.sendMessage("No photo found in the message.", event.threadID);
  }

  const apiKey = "c2_VGo5roK1WpzPdVPKvbhL4QBd9FT7_hJjyyJULLBxnH5-D";
  const endpoint = "https://developer.remini.ai/api";

  try {
    for (const attachment of attachments) {
      const photoUrl = attachment.url;
      const createTaskResponse = await axios.post(`${endpoint}/tasks`, {
        apiKey,
        image: photoUrl
      });

      const taskId = createTaskResponse.data.id;

      await axios.post(`${endpoint}/tasks/${taskId}/process`, {
        apiKey
      });

      let taskStatus = "PROCESSING";
      while (taskStatus === "PROCESSING") {
        const getTaskResponse = await axios.get(`${endpoint}/tasks/${taskId}`, {
          params: { apiKey }
        });

        taskStatus = getTaskResponse.data.status;

        if (taskStatus === "DONE") {
          const enhancedUrl = getTaskResponse.data.result;
          api.sendMessage({ body: enhancedUrl, attachment: axios.get(enhancedUrl, { responseType: 'arraybuffer' }) }, event.threadID);
        } else if (taskStatus === "FAILED") {
          api.sendMessage("Failed to enhance the photo.", event.threadID);
        } else {
          await new Promise(resolve => setTimeout(resolve, 1000)); // Wait for 1 second before checking the task status again
        }
      }
    }
  } catch (error) {
    console.error("Remini API error:", error);
    api.sendMessage("An error occurred while enhancing the photo.", event.threadID);
  }
};
