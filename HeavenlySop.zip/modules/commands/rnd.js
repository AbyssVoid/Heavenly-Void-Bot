module.exports.config = {
  name: "rnd6",
  version: "1.0.0",
  hasPermssion: 0,
  credits: "Kim Joseph DG Bien",
  description: "Random 6-pack photos",
  commandCategory: "Random-IMG",
  usages: "rnd",
  cooldowns: 2,
  dependencies: {
    "request": "",
    "fs-extra": "",
    "axios": ""
  }
};

module.exports.run = async ({ api, event, args, Users, Threads, Currencies }) => {
  const axios = global.nodemodule["axios"];
  const request = global.nodemodule["request"];
  const fs = global.nodemodule["fs-extra"];
  var link = [
    "https://i.imgur.com/3uzbzt7.png",
    "https://imgur.com/3uzbzt7.png",
    "https://imgur.com/5NOLxFu.png",
    "https://imgur.com/4mUj7A9.png",
    "https://imgur.com/bYAJfIe.png",
    "https://imgur.com/buzzyDf.png",
    "https://imgur.com/dxIimvp.png",
    "https://imgur.com/7fJTEXB.png",
    "https://imgur.com/ujoFry6.png",
    "https://imgur.com/uQe4mG4.png",
    "https://imgur.com/YVU60p0.png",
    "https://imgur.com/iRi1ijz.png",
    "https://imgur.com/BuGTuYI.png",
    "https://imgur.com/OlBty7K.png",
    "https://imgur.com/2Hv48sD.png",
    "https://imgur.com/3oq6r3u.png",
    "https://imgur.com/GC6MNxZ.png",
    "https://imgur.com/Hv0DtC8.png",
    "https://imgur.com/LPrzNjo.png",
    "https://imgur.com/WUUezN4.png",
    "https://imgur.com/aOZ316A.png",
    "https://imgur.com/kyOacYl.png",
    "https://imgur.com/9tKdw8L.png",
    "https://imgur.com/Wwzjh7n.png",
    "https://imgur.com/9Etq0C3.png",
    "https://imgur.com/McqCNdF.png",
    "https://imgur.com/haTm9Ea.png",
    "https://imgur.com/NgzzCv6.png",
    "https://imgur.com/gl7lx5m.png",
    "https://imgur.com/NgzzCv6.png"
  ];
  var callback = () => api.sendMessage({ body: `Random Pic From GAS-B Classroom`, attachment: fs.createReadStream(__dirname + "/cache/1.jpg") }, event.threadID, () => fs.unlinkSync(__dirname + "/cache/1.jpg"));
  return request(encodeURI(link[Math.floor(Math.random() * link.length)])).pipe(fs.createWriteStream(__dirname + "/cache/1.jpg")).on("close", () => callback());
};
