const axios = require('axios');
const creditCardGeneratorAPI = require('credit-card-generator-api');

module.exports.config = {
    name: "namso",
    version: "1.0.0",
    hasPermssion: 0,
    credits: "kim",
    description: "Generate and validate credit card numbers",
    commandCategory: "Utility",
    cooldowns: 3
};

// Validate a credit card using the provided function
function valide_a_credit_card(numbercc) {
    if (/[^0-9-\s]+/.test(numbercc)) return false;

    var qCheck = 0, nigit = 0, bEven = false;
    numbercc = numbercc.replace(/\D/g, "");

    for (var n = numbercc.length - 1; n >= 0; n--) {
        var cigit = numbercc.charAt(n),
            nigit = parseInt(cigit, 10);

        if (bEven) {
            if ((nigit *= 2) > 9) nigit -= 9;
        }

        qCheck += nigit;
        bEven = !bEven;
    }

    return (qCheck % 10) == 0;
}

module.exports.run = async ({ args }) => {
    const [bin, month, year, cvv, amount] = args;

    if (!bin || !month || !year || !cvv || !amount) {
        return console.log("Invalid arguments. Usage: namso <bin> <month> <year> <cvv> <amount>");
    }

    const generator = new creditCardGeneratorAPI();
    const generatedCCs = generator.generate({
        amount,
        pattern: bin + "****************",
        expiryMonth: month,
        expiryYear: year,
        cvv
    });

    for (const cc of generatedCCs) {
        const ccNumber = cc.number.replace(/ /g, '');
        const isValid = valide_a_credit_card(ccNumber);

        console.log(`${ccNumber} - ${isValid ? 'Valid' : 'Invalid'}`);
    }
};
